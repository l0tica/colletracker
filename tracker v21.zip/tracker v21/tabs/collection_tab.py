import customtkinter as ctk
from tkinter import messagebox
from data import calc_pct, save_profiles, get_active_data
from widgets import CollectionListItem, SlotWidget
from dialogs import AddCollectionDialog
from constants import TABS, pct_color, COLORS


class CollectionDetail(ctk.CTkScrollableFrame):
    def __init__(self, parent, collection: dict, on_change, on_delete, on_edit):
        super().__init__(parent)
        self._col = collection
        self._on_change = on_change
        self._on_delete = on_delete
        self._on_edit = on_edit
        self._slot_widgets: list[SlotWidget] = []
        self._needed_frame = None
        self._ms_buttons: list[ctk.CTkButton] = []
        self._build()

    def _build(self):
        c = self._col
        pct = calc_pct(c)
        self._build_header(c)
        self._build_needed(c)
        self._build_milestones(c, pct)
        self._build_rows(c)

    def _build_header(self, c):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(12, 2))
        ctk.CTkLabel(
            header, text=c["name"],
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(side="left")
        ctk.CTkButton(
            header, text="✎ Edit", width=70, height=28,
            command=self._on_edit
        ).pack(side="right", padx=4)
        ctk.CTkButton(
            header, text="🗑 Delete", width=80, height=28,
            fg_color="transparent", border_width=1, text_color="gray",
            command=self._on_delete
        ).pack(side="right", padx=4)
        toggle_text = "Set Inactive" if c.get("active", True) else "Set Active"
        ctk.CTkButton(
            header, text=toggle_text, width=100, height=28,
            fg_color="transparent", border_width=1,
            command=self._toggle_active
        ).pack(side="right", padx=4)

        self._progress_label = ctk.CTkLabel(
            self,
            text=f"Progress: {calc_pct(c)}%  |  Stat: {c['stat_name']}",
            text_color="gray")
        self._progress_label.pack(anchor="w", padx=12, pady=(0, 4))

    def _build_needed(self, c):
        self._needed_frame = ctk.CTkFrame(self)
        self._needed_frame.pack(fill="x", padx=12, pady=(4, 8))
        self._refresh_needed(c)

    def _refresh_needed(self, c):
        for w in self._needed_frame.winfo_children():
            w.destroy()
        incomplete = [
            s for r in c["rows"]
            for s in r["slots"]
            if s["goal"] > 0 and s["current"] < s["goal"]
        ]
        if not incomplete:
            return
        ctk.CTkLabel(
            self._needed_frame, text="Still needed",
            font=ctk.CTkFont(weight="bold")
        ).pack(anchor="w", padx=8, pady=(6, 4))
        wrap = ctk.CTkFrame(self._needed_frame, fg_color="transparent")
        wrap.pack(fill="x", padx=8, pady=(0, 8))
        for slot in incomplete:
            left = slot["goal"] - slot["current"]
            pill = ctk.CTkFrame(wrap)
            pill.pack(side="left", padx=4, pady=2)
            ctk.CTkLabel(
                pill, text=slot.get("name") or "?",
                font=ctk.CTkFont(size=11), text_color="gray"
            ).pack(padx=8, pady=(4, 0))
            ctk.CTkLabel(
                pill, text=f"{left} left",
                text_color=COLORS["orange"]
            ).pack(padx=8, pady=(0, 4))

    def _build_milestones(self, c, pct):
        ms_frame = ctk.CTkFrame(self)
        ms_frame.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(
            ms_frame, text="Milestones",
            font=ctk.CTkFont(weight="bold")
        ).pack(anchor="w", padx=8, pady=(6, 4))
        mrow = ctk.CTkFrame(ms_frame, fg_color="transparent")
        mrow.pack(fill="x", padx=8, pady=(0, 8))
        self._ms_buttons = []
        for ms in c.get("milestones", []):
            reached = pct >= ms["pct"]
            color = COLORS["green_dark"] if reached else "#444"
            label = (
                f"{ms['pct']}%\n{c['stat_name']} {ms['value']}\n"
                f"{'✓ Reached' if reached else 'Locked'}"
            )
            btn = ctk.CTkButton(
                mrow, text=label, fg_color=color,
                hover_color=color, cursor="arrow",
                width=150, height=60, command=lambda: None)
            btn.pack(side="left", padx=6)
            self._ms_buttons.append((btn, ms))

    def _refresh_milestones(self, pct):
        for btn, ms in self._ms_buttons:
            reached = pct >= ms["pct"]
            color = COLORS["green_dark"] if reached else "#444"
            label = (
                f"{ms['pct']}%\n{self._col['stat_name']} {ms['value']}\n"
                f"{'✓ Reached' if reached else 'Locked'}"
            )
            btn.configure(text=label, fg_color=color, hover_color=color)

    def _build_rows(self, c):
        self._slot_widgets = []
        for ri, row in enumerate(c.get("rows", [])):
            rf = ctk.CTkFrame(self)
            rf.pack(fill="x", padx=12, pady=6)
            rname = row.get("name") or f"Row {ri + 1}"
            qty = row.get("reward_qty", "")
            rtype = row.get("reward_type", "")
            reward_str = f"{qty}x {rtype}".strip() if qty or rtype else ""

            hrow = ctk.CTkFrame(rf, fg_color="transparent")
            hrow.pack(fill="x", padx=8, pady=(6, 2))
            ctk.CTkLabel(
                hrow, text=rname, font=ctk.CTkFont(weight="bold")
            ).pack(side="left")

            if reward_str:
                claimed = row.get("reward_claimed", False)
                reward_label = ctk.CTkLabel(
                    hrow,
                    text=f"Reward: {reward_str}{'  ✓' if claimed else ''}",
                    text_color=COLORS["green_dark"] if claimed else "gray")
                reward_label.pack(side="left", padx=12)
                claim_btn = ctk.CTkButton(
                    hrow,
                    text="Unclaim" if claimed else "Claim",
                    width=70, height=24)
                claim_btn.configure(
                    command=lambda r=row, rl=reward_label, cb=claim_btn: self._toggle_reward(r, rl, cb))
                claim_btn.pack(side="right", padx=8)

            slots_frame = ctk.CTkFrame(rf, fg_color="transparent")
            slots_frame.pack(fill="x", padx=8, pady=(4, 8))
            for slot in row.get("slots", []):
                sw = SlotWidget(slots_frame, slot, on_change=lambda: self._slot_changed())
                sw.pack(side="left", padx=4, pady=2)
                self._slot_widgets.append(sw)

    def _slot_changed(self):
        pct = calc_pct(self._col)
        self._progress_label.configure(
            text=f"Progress: {pct}%  |  Stat: {self._col['stat_name']}")
        self._refresh_needed(self._col)
        self._refresh_milestones(pct)
        self._on_change()

    def _toggle_reward(self, row, label, btn):
        row["reward_claimed"] = not row.get("reward_claimed", False)
        claimed = row["reward_claimed"]
        qty = row.get("reward_qty", "")
        rtype = row.get("reward_type", "")
        reward_str = f"{qty}x {rtype}".strip() if qty or rtype else ""
        label.configure(
            text=f"Reward: {reward_str}{'  ✓' if claimed else ''}",
            text_color=COLORS["green_dark"] if claimed else "gray")
        btn.configure(text="Unclaim" if claimed else "Claim")
        self._on_change()

    def _toggle_active(self):
        self._col["active"] = not self._col.get("active", True)
        self._on_change()

    def _on_delete(self):
        self._on_delete()


class CollectionTab(ctk.CTkFrame):
    def __init__(self, parent, tab: str, get_profiles, save_cb, refresh_all_cb):
        super().__init__(parent, fg_color="transparent")
        self._tab = tab
        self._get_profiles = get_profiles
        self._save_cb = save_cb
        self._refresh_all_cb = refresh_all_cb
        self._selected_idx = 0
        self._sort = "Default"
        self._list_items: dict[int, CollectionListItem] = {}
        self._build()

    def _data(self):
        return get_active_data(self._get_profiles())

    def _build(self):
        left = ctk.CTkFrame(self, width=245)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        ctk.CTkButton(
            left, text="+ Add Collection",
            command=self._add_collection
        ).pack(fill="x", padx=8, pady=(8, 4))

        sort_row = ctk.CTkFrame(left, fg_color="transparent")
        sort_row.pack(fill="x", padx=8, pady=(0, 4))
        ctk.CTkLabel(sort_row, text="Sort:", font=ctk.CTkFont(size=12)).pack(side="left")
        self._sort_var = ctk.StringVar(value="Default")
        ctk.CTkComboBox(
            sort_row,
            values=["Default", "Name", "% Asc", "% Desc"],
            variable=self._sort_var, width=130,
            command=self._on_sort_change
        ).pack(side="left", padx=4)

        self._inactive_var = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(
            left, text="Show inactive",
            variable=self._inactive_var,
            command=self._rebuild_list
        ).pack(anchor="w", padx=8, pady=(0, 4))

        self._list_frame = ctk.CTkScrollableFrame(left)
        self._list_frame.pack(fill="both", expand=True, padx=4)

        self._right = ctk.CTkFrame(self)
        self._right.pack(side="left", fill="both", expand=True)

        self._rebuild_list()

    def _on_sort_change(self, _=None):
        self._sort = self._sort_var.get()
        self._rebuild_list()

    def _rebuild_list(self):
        """Full rebuild of list — only called on sort/filter change or add/delete."""
        for w in self._list_frame.winfo_children():
            w.destroy()
        self._list_items.clear()
        data = self._data()
        cols = list(enumerate(data.get(self._tab, [])))

        if self._sort == "Name":
            cols.sort(key=lambda x: x[1]["name"].lower())
        elif self._sort == "% Asc":
            cols.sort(key=lambda x: calc_pct(x[1]))
        elif self._sort == "% Desc":
            cols.sort(key=lambda x: calc_pct(x[1]), reverse=True)

        shown = False
        for orig_idx, c in cols:
            active = c.get("active", True)
            if not self._inactive_var.get() and not active:
                continue
            shown = True
            pct = calc_pct(c)
            item = CollectionListItem(
                self._list_frame, c["name"], pct, active,
                on_click=lambda i=orig_idx: self._select(i))
            item.pack(fill="x", pady=2)
            self._list_items[orig_idx] = item

        if shown and data.get(self._tab):
            idx = min(self._selected_idx, len(data[self._tab]) - 1)
            self._show_collection(idx)

    def _update_list_item(self, idx: int):
        """Update only the specific list item's progress — no rebuild."""
        data = self._data()
        cols = data.get(self._tab, [])
        if idx >= len(cols):
            return
        c = cols[idx]
        pct = calc_pct(c)
        active = c.get("active", True)
        if idx in self._list_items:
            self._list_items[idx].update_progress(pct, active)

    def refresh_list(self):
        self._rebuild_list()

    def _select(self, idx: int):
        self._selected_idx = idx
        self._show_collection(idx)

    def _show_collection(self, idx: int):
        for w in self._right.winfo_children():
            w.destroy()
        data = self._data()
        cols = data.get(self._tab, [])
        if not cols or idx >= len(cols):
            return
        c = cols[idx]
        detail = CollectionDetail(
            self._right, c,
            on_change=lambda: self._on_change(idx),
            on_delete=lambda: self._delete(idx),
            on_edit=lambda: self._edit(idx))
        detail.pack(fill="both", expand=True)

    def _on_change(self, idx: int):
        self._save_cb()
        self._update_list_item(idx)
        self._refresh_all_cb()

    def _add_collection(self):
        def callback(col):
            data = self._data()
            data[self._tab].append(col)
            self._save_cb()
            self._selected_idx = len(data[self._tab]) - 1
            self._rebuild_list()
            self._refresh_all_cb()
        AddCollectionDialog(self, self._data(), callback)

    def _edit(self, idx: int):
        data = self._data()
        existing = data[self._tab][idx]
        def callback(col):
            data[self._tab][idx] = col
            self._save_cb()
            self._rebuild_list()
            self._show_collection(idx)
            self._refresh_all_cb()
        AddCollectionDialog(self, data, callback, existing=existing)

    def _delete(self, idx: int):
        data = self._data()
        name = data[self._tab][idx]["name"]
        if not messagebox.askyesno("Delete collection",
                                   f"Delete '{name}'? This cannot be undone."):
            return
        data[self._tab].pop(idx)
        self._save_cb()
        self._selected_idx = max(0, idx - 1)
        self._rebuild_list()
        for w in self._right.winfo_children():
            w.destroy()
        self._refresh_all_cb()