import customtkinter as ctk
from data import calc_pct, add_to_list, get_active_data
from widgets import SlotWidget
from constants import TABS, pct_color, COLORS


class ItemsTab(ctk.CTkFrame):
    def __init__(self, parent, get_profiles, save_cb, refresh_all_cb):
        super().__init__(parent, fg_color="transparent")
        self._get_profiles = get_profiles
        self._save_cb = save_cb
        self._refresh_all_cb = refresh_all_cb
        self._current_item = None
        self._card_labels: dict = {}
        self._build()

    def _data(self):
        return get_active_data(self._get_profiles())

    def _build(self):
        left = ctk.CTkFrame(self, width=240)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        ctk.CTkLabel(
            left, text="Item database",
            font=ctk.CTkFont(weight="bold")
        ).pack(pady=(10, 4), padx=8, anchor="w")

        self._search_var = ctk.StringVar()
        self._search_var.trace_add("write", lambda *_: self._populate_list())
        ctk.CTkEntry(
            left, textvariable=self._search_var,
            placeholder_text="Search items..."
        ).pack(fill="x", padx=8, pady=(0, 6))

        add_row = ctk.CTkFrame(left, fg_color="transparent")
        add_row.pack(fill="x", padx=8, pady=(0, 6))
        self._new_item = ctk.CTkEntry(add_row, placeholder_text="New item name")
        self._new_item.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self._new_item.bind("<Return>", lambda e: self._add_item())
        ctk.CTkButton(add_row, text="+", width=30, command=self._add_item).pack(side="left")

        self._list_frame = ctk.CTkScrollableFrame(left)
        self._list_frame.pack(fill="both", expand=True, padx=4)

        self._right = ctk.CTkScrollableFrame(self)
        self._right.pack(side="left", fill="both", expand=True)

        self._populate_list()

    def _add_item(self):
        name = self._new_item.get().strip()
        if name:
            add_to_list(self._data().get("item_db", []), name)
            self._save_cb()
            self._new_item.delete(0, "end")
            self._populate_list()

    def _populate_list(self):
        for w in self._list_frame.winfo_children():
            w.destroy()
        data = self._data()
        q = self._search_var.get().strip().lower()
        items = sorted(i for i in data.get("item_db", []) if q in i.lower())
        for item in items:
            ctk.CTkButton(
                self._list_frame, text=item, anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray85", "gray25"),
                command=lambda i=item: self._show_item(i)
            ).pack(fill="x", pady=2)

    def _show_item(self, item_name: str):
        self._current_item = item_name
        self._card_labels.clear()
        for w in self._right.winfo_children():
            w.destroy()
        data = self._data()

        ctk.CTkLabel(
            self._right, text=item_name,
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(anchor="w", padx=12, pady=(12, 4))
        ctk.CTkLabel(
            self._right, text="Collections requiring this item:",
            text_color="gray"
        ).pack(anchor="w", padx=12, pady=(0, 8))

        found = False
        for tab in TABS:
            for col in data.get(tab, []):
                for row in col["rows"]:
                    for slot in row["slots"]:
                        if slot.get("name", "").lower() == item_name.lower():
                            found = True
                            self._build_card(col, row, slot, tab, item_name)

        if not found:
            ctk.CTkLabel(
                self._right,
                text="This item isn't used in any collection yet.",
                text_color="gray"
            ).pack(padx=12, pady=20)

    def _build_card(self, col, row, slot, tab, item_name):
        pct = calc_pct(col)
        color = pct_color(pct)
        key = id(slot)

        cf = ctk.CTkFrame(self._right)
        cf.pack(fill="x", pady=6, padx=12)

        top = ctk.CTkFrame(cf, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=(8, 2))
        ctk.CTkLabel(
            top, text=col["name"],
            font=ctk.CTkFont(weight="bold")
        ).pack(side="left")
        ctk.CTkLabel(top, text=f"[{tab}]", text_color="gray").pack(side="left", padx=6)

        pct_lbl = ctk.CTkLabel(top, text=f"{pct}%", text_color=color)
        pct_lbl.pack(side="right", padx=8)

        info = ctk.CTkFrame(cf, fg_color="transparent")
        info.pack(fill="x", padx=8, pady=2)
        rname = row.get("name") or "Row"
        left_amount = max(0, slot["goal"] - slot["current"])

        info_lbl = ctk.CTkLabel(
            info,
            text=f"Row: {rname}  |  {slot['current']}/{slot['goal']}  |  Need: {left_amount}",
            text_color="gray", font=ctk.CTkFont(size=12))
        info_lbl.pack(side="left")

        stat = col.get("stat_name", "")
        ms100 = col["milestones"][2]["value"] if col.get("milestones") else ""
        if stat:
            ctk.CTkLabel(
                info, text=f"Finish: {stat} {ms100}",
                text_color=COLORS["orange"],
                font=ctk.CTkFont(size=12)
            ).pack(side="right", padx=8)

        self._card_labels[key] = (pct_lbl, info_lbl, col)

        def on_slot_change(s=slot, pl=pct_lbl, il=info_lbl, c=col):
            new_pct = calc_pct(c)
            new_color = pct_color(new_pct)
            left = max(0, s["goal"] - s["current"])
            pl.configure(text=f"{new_pct}%", text_color=new_color)
            il.configure(
                text=f"Row: {rname}  |  {s['current']}/{s['goal']}  |  Need: {left}")
            self._save_cb()
            self._refresh_all_cb()

        sw = SlotWidget(cf, slot, on_change=on_slot_change)
        sw.pack(anchor="w", padx=8, pady=(2, 8))

    def refresh(self):
        self._populate_list()
        if self._current_item:
            self._show_item(self._current_item)