import customtkinter as ctk
from data import calc_pct, calc_earned_stat, get_active_data
from constants import TABS, pct_color


class OverallTab(ctk.CTkScrollableFrame):
    def __init__(self, parent, get_profiles):
        super().__init__(parent)
        self._get_profiles = get_profiles
        self._show_all_rewards = False
        self._stat_labels: dict[str, tuple] = {}
        self._reward_labels: dict[str, tuple] = {}
        self._col_pct_labels: dict[str, ctk.CTkLabel] = {}
        self._built = False
        self.build()

    def _data(self):
        return get_active_data(self._get_profiles())

    def build(self):
        """Full build — called on profile switch or first load only."""
        for w in self.winfo_children():
            w.destroy()
        self._stat_labels.clear()
        self._reward_labels.clear()
        self._col_pct_labels.clear()
        data = self._data()
        self._build_stats(data)
        self._build_rewards(data)
        self._build_collection_list(data)
        self._built = True

    def refresh(self):
        """Soft refresh — updates labels in place, no rebuild."""
        if not self._built:
            self.build()
            return
        data = self._data()
        self._refresh_stats(data)
        self._refresh_rewards(data)
        self._refresh_collection_list(data)

    def _calc_stat_totals(self, data):
        stat_totals: dict[str, float] = {}
        stat_earned: dict[str, float] = {}
        for tab in TABS:
            for c in data.get(tab, []):
                sn = c.get("stat_name", "")
                if not sn:
                    continue
                try:
                    total_v = float(c["milestones"][2]["value"]) if c["milestones"][2]["value"] else 0.0
                except (ValueError, IndexError):
                    total_v = 0.0
                stat_totals[sn] = stat_totals.get(sn, 0.0) + total_v
                stat_earned[sn] = stat_earned.get(sn, 0.0) + calc_earned_stat(c)
        return stat_totals, stat_earned

    def _calc_reward_totals(self, data):
        reward_totals: dict[str, list] = {}
        for tab in TABS:
            for c in data.get(tab, []):
                for row in c.get("rows", []):
                    rtype = row.get("reward_type", "").strip()
                    if not rtype:
                        continue
                    try:
                        qty = int(row.get("reward_qty", 0))
                    except (ValueError, TypeError):
                        qty = 0
                    if rtype not in reward_totals:
                        reward_totals[rtype] = [0, 0]
                    reward_totals[rtype][1] += qty
                    if row.get("reward_claimed", False):
                        reward_totals[rtype][0] += qty
        return reward_totals

    def _build_stats(self, data):
        ctk.CTkLabel(
            self, text="Total stats earned",
            font=ctk.CTkFont(size=15, weight="bold")
        ).pack(anchor="w", padx=12, pady=(12, 6))

        stat_totals, stat_earned = self._calc_stat_totals(data)

        if stat_totals:
            sf = ctk.CTkFrame(self)
            sf.pack(fill="x", padx=12, pady=4)
            for sn in sorted(stat_totals):
                total = stat_totals[sn]
                earned = stat_earned.get(sn, 0.0)
                row = ctk.CTkFrame(sf, fg_color="transparent")
                row.pack(fill="x", padx=8, pady=3)
                ctk.CTkLabel(row, text=sn, width=220, anchor="w").pack(side="left")
                earned_lbl = ctk.CTkLabel(
                    row, text=f"+{int(earned)} earned",
                    text_color="#1D9E75", width=140)
                earned_lbl.pack(side="left")
                total_lbl = ctk.CTkLabel(
                    row, text=f"/ +{int(total)} total",
                    text_color="gray")
                total_lbl.pack(side="left")
                self._stat_labels[sn] = (earned_lbl, total_lbl)
        else:
            ctk.CTkLabel(
                self, text="No stats yet — add some collections!",
                text_color="gray"
            ).pack(padx=12)

    def _refresh_stats(self, data):
        stat_totals, stat_earned = self._calc_stat_totals(data)
        for sn, (earned_lbl, total_lbl) in self._stat_labels.items():
            earned = stat_earned.get(sn, 0.0)
            total = stat_totals.get(sn, 0.0)
            earned_lbl.configure(text=f"+{int(earned)} earned")
            total_lbl.configure(text=f"/ +{int(total)} total")

    def _build_rewards(self, data):
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(16, 6))
        ctk.CTkLabel(
            header, text="Total rewards",
            font=ctk.CTkFont(size=15, weight="bold")
        ).pack(side="left")
        self._toggle_btn = ctk.CTkButton(
            header,
            text="Show all" if not self._show_all_rewards else "Show claimed only",
            width=130, height=26,
            fg_color="transparent", border_width=1,
            command=self._toggle_rewards)
        self._toggle_btn.pack(side="left", padx=12)

        self._rewards_frame = ctk.CTkFrame(self)
        self._rewards_frame.pack(fill="x", padx=12, pady=4)
        self._populate_rewards(data)

    def _populate_rewards(self, data):
        for w in self._rewards_frame.winfo_children():
            w.destroy()
        self._reward_labels.clear()
        reward_totals = self._calc_reward_totals(data)

        if not reward_totals:
            ctk.CTkLabel(
                self._rewards_frame,
                text="No rewards found — add collections with row rewards!",
                text_color="gray"
            ).pack(padx=8, pady=4)
            return

        shown = 0
        for rtype in sorted(reward_totals):
            claimed, total = reward_totals[rtype]
            if not self._show_all_rewards and claimed == 0:
                continue
            shown += 1
            row = ctk.CTkFrame(self._rewards_frame, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=3)
            ctk.CTkLabel(row, text=rtype, width=220, anchor="w").pack(side="left")
            claimed_lbl = ctk.CTkLabel(
                row, text=f"{claimed} claimed",
                text_color="#1D9E75", width=140)
            claimed_lbl.pack(side="left")
            total_lbl = ctk.CTkLabel(
                row, text=f"/ {total} total", text_color="gray")
            total_lbl.pack(side="left")
            self._reward_labels[rtype] = (claimed_lbl, total_lbl)

        if shown == 0:
            ctk.CTkLabel(
                self._rewards_frame,
                text="No rewards claimed yet.",
                text_color="gray"
            ).pack(padx=8, pady=4)

    def _refresh_rewards(self, data):
        reward_totals = self._calc_reward_totals(data)
        for rtype, (claimed_lbl, total_lbl) in self._reward_labels.items():
            if rtype in reward_totals:
                claimed, total = reward_totals[rtype]
                claimed_lbl.configure(text=f"{claimed} claimed")
                total_lbl.configure(text=f"/ {total} total")

    def _toggle_rewards(self):
        self._show_all_rewards = not self._show_all_rewards
        self._toggle_btn.configure(
            text="Show all" if not self._show_all_rewards else "Show claimed only")
        self._populate_rewards(self._data())

    def _build_collection_list(self, data):
        ctk.CTkLabel(
            self, text="All collections",
            font=ctk.CTkFont(size=15, weight="bold")
        ).pack(anchor="w", padx=12, pady=(18, 6))

        for tab in TABS:
            cols = data.get(tab, [])
            if not cols:
                continue
            ctk.CTkLabel(
                self, text=tab,
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color="gray"
            ).pack(anchor="w", padx=16, pady=(8, 2))

            for c in cols:
                pct = calc_pct(c)
                color = pct_color(pct)
                active = c.get("active", True)
                stat = c.get("stat_name", "")
                ms100 = c["milestones"][2]["value"] if c.get("milestones") else ""

                cr = ctk.CTkFrame(self)
                cr.pack(fill="x", padx=12, pady=2)
                ctk.CTkLabel(
                    cr, text=c["name"], anchor="w",
                    text_color=("white" if active else "gray")
                ).pack(side="left", padx=8)

                pct_lbl = ctk.CTkLabel(cr, text=f"{pct}%", text_color=color)
                pct_lbl.pack(side="right", padx=8)

                if stat and ms100:
                    ctk.CTkLabel(
                        cr, text=f"{stat} +{ms100}",
                        text_color="gray", font=ctk.CTkFont(size=12)
                    ).pack(side="right", padx=16)

                key = f"{tab}:{c['name']}"
                self._col_pct_labels[key] = pct_lbl

    def _refresh_collection_list(self, data):
        for tab in TABS:
            for c in data.get(tab, []):
                key = f"{tab}:{c['name']}"
                if key in self._col_pct_labels:
                    pct = calc_pct(c)
                    color = pct_color(pct)
                    self._col_pct_labels[key].configure(
                        text=f"{pct}%", text_color=color)