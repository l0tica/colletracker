import customtkinter as ctk
from data import calc_pct, calc_earned_stat, get_active_data
from constants import TABS, pct_color


class OverallTab(ctk.CTkScrollableFrame):
    def __init__(self, parent, get_profiles):
        super().__init__(parent)
        self._get_profiles = get_profiles
        self.build()

    def _data(self):
        return get_active_data(self._get_profiles())

    def build(self):
        for w in self.winfo_children():
            w.destroy()
        data = self._data()
        self._build_stats(data)
        self._build_collection_list(data)

    def _build_stats(self, data):
        ctk.CTkLabel(
            self, text="Total stats earned", font=ctk.CTkFont(size=15, weight="bold")
        ).pack(anchor="w", padx=12, pady=(12, 6))

        stat_totals: dict[str, float] = {}
        stat_earned: dict[str, float] = {}

        for tab in TABS:
            for c in data.get(tab, []):
                sn = c.get("stat_name", "")
                if not sn:
                    continue
                try:
                    total_v = float(c["milestones"][2]["value"]) if c["milestones"][2]["value"] else 0.0
                except (ValueError, IndexError):
                    total_v = 0.0
                stat_totals[sn] = stat_totals.get(sn, 0.0) + total_v
                stat_earned[sn] = stat_earned.get(sn, 0.0) + calc_earned_stat(c)

        if stat_totals:
            sf = ctk.CTkFrame(self)
            sf.pack(fill="x", padx=12, pady=4)
            for sn in sorted(stat_totals):
                total = stat_totals[sn]
                earned = stat_earned.get(sn, 0.0)
                row = ctk.CTkFrame(sf, fg_color="transparent")
                row.pack(fill="x", padx=8, pady=3)
                ctk.CTkLabel(row, text=sn, width=220, anchor="w").pack(side="left")
                ctk.CTkLabel(
                    row, text=f"+{int(earned)} earned", text_color="#1D9E75", width=140
                ).pack(side="left")
                ctk.CTkLabel(
                    row, text=f"/ +{int(total)} total", text_color="gray"
                ).pack(side="left")
        else:
            ctk.CTkLabel(
                self, text="No stats yet — add some collections!", text_color="gray"
            ).pack(padx=12)

    def _build_collection_list(self, data):
        ctk.CTkLabel(
            self, text="All collections", font=ctk.CTkFont(size=15, weight="bold")
        ).pack(anchor="w", padx=12, pady=(18, 6))

        for tab in TABS:
            cols = data.get(tab, [])
            if not cols:
                continue
            ctk.CTkLabel(
                self, text=tab,
                font=ctk.CTkFont(size=13, weight="bold"), text_color="gray"
            ).pack(anchor="w", padx=16, pady=(8, 2))

            for c in cols:
                pct = calc_pct(c)
                color = pct_color(pct)
                active = c.get("active", True)
                stat = c.get("stat_name", "")
                ms100 = c["milestones"][2]["value"] if c.get("milestones") else ""

                cr = ctk.CTkFrame(self)
                cr.pack(fill="x", padx=12, pady=2)
                ctk.CTkLabel(
                    cr, text=c["name"], anchor="w",
                    text_color=("white" if active else "gray")
                ).pack(side="left", padx=8)
                ctk.CTkLabel(
                    cr, text=f"{pct}%", text_color=color
                ).pack(side="right", padx=8)
                if stat and ms100:
                    ctk.CTkLabel(
                        cr, text=f"{stat} +{ms100}",
                        text_color="gray", font=ctk.CTkFont(size=12)
                    ).pack(side="right", padx=16)